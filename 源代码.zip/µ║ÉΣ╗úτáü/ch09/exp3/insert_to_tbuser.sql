delete from tb_user;

INSERT INTO tb_user(name,sex,birthday,status) VALUES ('李明',true,'1990-10-10',1);
INSERT INTO tb_user(name,sex,birthday,status) VALUES ('王倩',false,'1992-06-01',0);
INSERT INTO tb_user(name,sex) VALUES ('张丽',false);
INSERT INTO tb_user(name) VALUES ('Lee');




