//-----------------------------------------------------------------
//	hello.c// �ó���Ϊ��ͨӦ�ó�����Ա���kello.c�Ĳ���
//	This application outputs a brief message to the console.
//		compile using: $ gcc -o hello hello.c
//		execute using: $ ./hello//
//	programmer: Fang Sheng 
//	written on: Oct. 2014
//-----------------------------------------------------------------

#include <stdio.h>		// for printf()

int main( void )
{
	printf( "\n   Hello, students from SDUST! \n" );
	return	0;
}
