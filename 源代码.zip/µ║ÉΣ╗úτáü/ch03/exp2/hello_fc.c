#include <stdio.h>
#include"hello.h"
void hello(char* name){
	printf("hello %s\n",name);
}

