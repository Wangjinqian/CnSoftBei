#ifndef _HELLO_H
#define _HELLO_H
void hello(char *name);
#endif
