//两个整数做减法
int sub(int a,int b){
return (a-b);
}
