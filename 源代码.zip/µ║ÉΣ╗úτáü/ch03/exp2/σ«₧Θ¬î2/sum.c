//两个整数做加法
int sum(int a,int b){
 return (a+b);
}
