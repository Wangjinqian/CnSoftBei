#ifndef _HEAD_H
#define _HEAD_H
int sub(int a,int b);
int sum(int a,int b);
#endif
